# Predictive Analytics and Visualizations based on Crime patterns in India.
It a python based web application which runs Machine Learning algorithm in the back-end for prediction purposes.
Please note that the website given for this project may or may not work because it was hosted on pythonanywhere.com which is unfortunately available until I have free student subscription only.
